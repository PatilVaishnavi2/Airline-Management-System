package com.airline.dao;

import java.sql.*;
import java.util.*;
import com.airline.model.Flight;

public class FlightDAO {

    public static boolean addFlight(Flight flight) {
        boolean status = false;
        try (Connection con = DBConnection.getConnection()) {
            String query = "INSERT INTO flights (fl_code, source, destination, departure_time, arrival_time, seats) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, flight.getFlCode());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getSeats());

            status = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public static List<Flight> getAllFlights() {
        List<Flight> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM flights";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Flight f = new Flight();
                f.setId(rs.getInt("id"));
                f.setFlCode(rs.getString("fl_code"));
                f.setSource(rs.getString("source"));
                f.setDestination(rs.getString("destination"));
                f.setDepartureTime(rs.getString("departure_time"));
                f.setArrivalTime(rs.getString("arrival_time"));
                f.setSeats(rs.getInt("seats"));
                list.add(f);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
