package com.airline.dao;

import java.sql.*;
import com.airline.model.Passenger;

public class BookingDAO {

    public static boolean bookTicket(Passenger p) {
        boolean status = false;
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO passengers (pnr_no, name, gender, address, nationality, ph_no, passport_no, fl_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getPnrNo());
            ps.setString(2, p.getName());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getAddress());
            ps.setString(5, p.getNationality());
            ps.setString(6, p.getPhNo());
            ps.setString(7, p.getPassportNo());
            ps.setString(8, p.getFlCode());

            status = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
    
    public static Passenger getPassengerByPNR(String pnrNo) {
        Passenger p = null;
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM passengers WHERE pnr_no = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pnrNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                p = new Passenger();
                p.setPnrNo(rs.getString("pnr_no"));
                p.setName(rs.getString("name"));
                p.setGender(rs.getString("gender"));
                p.setAddress(rs.getString("address"));
                p.setNationality(rs.getString("nationality"));
                p.setPhNo(rs.getString("ph_no"));
                p.setPassportNo(rs.getString("passport_no"));
                p.setFlCode(rs.getString("fl_code"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }
    
    public static boolean cancelTicket(String pnrNo) {
        boolean status = false;
        try (Connection con = DBConnection.getConnection()) {
            String sql = "DELETE FROM passengers WHERE pnr_no = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pnrNo);
            int rows = ps.executeUpdate();
            status = rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
    
    public static String generatePNR() {
    	String generatePnr="" ;
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT pnr_no FROM passengers ORDER BY pnr_no DESC LIMIT 1; ";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
            	generatePnr = rs.getString(1);
            	generatePnr = "PNR"+(Integer.parseInt(generatePnr.substring(3)) + 1) ;
            }
            else
            {
            	return "PNR1001";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return generatePnr;
    }
}
