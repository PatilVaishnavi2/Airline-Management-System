package com.airline.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.airline.dao.BookingDAO;

public class CancelTicketServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String pnr = request.getParameter("pnr_no");
        boolean result = BookingDAO.cancelTicket(pnr);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (result) {
            out.println("<h3>Ticket Cancelled Successfully!</h3>");
        } else {
            out.println("<h3>No booking found with PNR: " + pnr + "</h3>");
        }
    }
}
