package com.airline.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.airline.dao.BookingDAO;
import com.airline.model.Passenger;

public class PNRStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String pnr = request.getParameter("pnr_no");
        Passenger p = BookingDAO.getPassengerByPNR(pnr);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (p != null) {
            out.println("<h3>PNR Status Found:</h3>");
            out.println("<p><strong>Name:</strong> " + p.getName() + "</p>");
            out.println("<p><strong>Flight Code:</strong> " + p.getFlCode() + "</p>");
            out.println("<p><strong>Gender:</strong> " + p.getGender() + "</p>");
            out.println("<p><strong>Phone No:</strong> " + p.getPhNo() + "</p>");
            out.println("<p><strong>Passport No:</strong> " + p.getPassportNo() + "</p>");
        } else {
            out.println("<h3>No booking found with PNR: " + pnr + "</h3>");
        }
    }
}
