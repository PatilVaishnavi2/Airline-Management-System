package com.airline.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.airline.dao.FlightDAO;
import com.airline.model.Flight;

public class AddFlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String fl_code = request.getParameter("fl_code");
        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String departure = request.getParameter("departure_time");
        String arrival = request.getParameter("arrival_time");
        int seats = Integer.parseInt(request.getParameter("seats"));

        Flight flight = new Flight();
        flight.setFlCode(fl_code);
        flight.setSource(source);
        flight.setDestination(destination);
        flight.setDepartureTime(departure);
        flight.setArrivalTime(arrival);
        flight.setSeats(seats);

        boolean result = FlightDAO.addFlight(flight);

        if (result) {
            response.sendRedirect("viewFlights.jsp");
        } else {
            response.getWriter().println("Error adding flight.");
        }
    }
}
