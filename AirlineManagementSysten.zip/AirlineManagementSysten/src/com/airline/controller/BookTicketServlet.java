package com.airline.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.airline.model.Passenger;
import com.airline.dao.BookingDAO;

public class BookTicketServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        Passenger p = new Passenger();
        p.setPnrNo(request.getParameter("pnr_no"));
        p.setName(request.getParameter("name"));
        p.setGender(request.getParameter("gender"));
        p.setAddress(request.getParameter("address"));
        p.setNationality(request.getParameter("nationality"));
        p.setPhNo(request.getParameter("ph_no"));
        p.setPassportNo(request.getParameter("passport_no"));
        p.setFlCode(request.getParameter("fl_code"));

        boolean result = BookingDAO.bookTicket(p);

        if (result) {
            response.getWriter().println("Ticket Booked Successfully! <br><a href='viewFlights.jsp'>View Flights</a>");
        } else {
            response.getWriter().println("Booking Failed! PNR may already exist.");
        }
    }
}
